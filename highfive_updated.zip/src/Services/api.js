const base_url = 'https://backendos.toon-flix.com'
<<<<<<< HEAD

// const base_url = `http://192.168.1.8:8810`
=======
>>>>>>> ca153361d4a5936876071c7cfdbaf79e6ef999ed
export {base_url}